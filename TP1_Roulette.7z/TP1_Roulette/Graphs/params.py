class Params:
    def __init__(self, title, xlabel, position, ylabel=""):
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.position = position
